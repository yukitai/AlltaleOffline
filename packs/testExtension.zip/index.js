Util.onload = function () {
  alert(Param.msg)
}